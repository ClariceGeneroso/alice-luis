//import da class fornecedor
import Fornecedor from "./Fornecedor.js";

//criar class
class FornecedorPessoa extends Fornecedor{

    //atributos
    #rg;
    #cpf;

    //criando construtor
    constructor(nome="Sem nome",fone = "(00) 0000-0000",rg="11.111.111-1",cpf="132.958.964-58"){
        super(nome,fone);
        this.#rg=rg;
        this.#cpf=cpf;
    }

    //criandos os métodos setters
    setRg(rg){
        this.#rg=rg;
    }

     setCpf(cpf){
        this.#cpf=cpf;
    }

     //criandos os métodos getters
    getRg(rg){
       return this.#rg
    }

     getCpf(cpf){
      return this.#cpf
    }
}

export default FornecedorPessoa