//criar a class
class Fornecedor{


//criar os atributos
#nome;
#fone;

//criando o método construtor
constructor(nome="Sem nome",fone = "00) 0000-0000"){
    this.#nome = nome;
    this.#fone = fone;
}

//criando os métodos setters
setNome(nome){
    this.#nome = nome;
}

setFone(fone){
    this.#fone = fone;
}


//criando os métodos getters
getNome(){
    return this.#nome;
}

getFone(){
    return this.#fone;
}

}


export default Fornecedor;