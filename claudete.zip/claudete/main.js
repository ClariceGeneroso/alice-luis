//import da class fornecedor e FornecedorPessoa
import Fornecedor from "./Fornecedor.js";
import FornecedorPessoa from "./FornecedorPessoa";

//
const objfornecedor = new Fornecedor("Pedro Silva","(11)97536-7894");

//exibir resultado
console.log(`Dados do Fornecedor:
    Nome: ${objfornecedor.getNome()}
    Fone: ${objfornecedor.getFone()}`)

/*criando e instanciando o objeto FornecedorPessoa no método construtor*/
const objfornecedorPessoa = new FornecedorPessoa ("Mirela Fontes","(11) 96874-1598","19.157.785-5","165.369.895-89");

//exibir dados
console.log(`os dados do Fornecedor Pessoa:
   Nome: ${objfornecedorPessoa.getNome()}
    Fone: ${objfornecedorPessoa.getFone()}
    Rg: ${objfornecedorPessoa.getRg}
    Cpf: ${objfornecedorPessoa.getCpf}`) 
  